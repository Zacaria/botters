import { chromium } from '@playwright/test'
import { writeFile } from 'node:fs/promises'
import { spawn } from 'node:child_process'
import assert from 'node:assert/strict'
const origin = 'http://127.0.0.1:8793', results = []
const server = spawn(process.execPath, ['scripts/online-dev.js'], { env: { ...process.env, PORT: '8793', BOTTERS_TEST_SPEED: '10' }, stdio: ['ignore','ignore','pipe'] })
let serverLog = ''; server.stderr.on('data', b => { serverLog += b })
let browser
try {
 for (let i=0;i<50;i++) { try { if ((await fetch(origin)).ok) break } catch {} await new Promise(r=>setTimeout(r,100)) }
 browser = await chromium.launch({ executablePath: '/usr/bin/brave-browser', args: ['--no-sandbox','--disable-dev-shm-usage'] })
 for (const mode of ['1v1','2v2','ffa4','ffa6']) {
  const context = await browser.newContext({ viewport: { width:1440, height:1100 } }), page = await context.newPage(), errors = []
  page.on('pageerror', e => errors.push(e.message))
  await context.addInitScript(() => { if (!localStorage.getItem('botters.prefs')) localStorage.setItem('botters.prefs', JSON.stringify({ minutes:3, planets:16, planning:10, withAgent:false, openingMine:true, opening:[{if:'always',then:'hold',on:true}] })) })
  await page.goto(origin); await page.locator('#startName').fill('Review '+mode); await page.locator('#startSolo').click(); await page.locator('#play').waitFor({state:'visible'})
  await page.locator('#setup').evaluate(e=>e.open=true)
  await page.locator(`#mode button[data-v="${mode}"]`).click()
  assert.equal(await page.evaluate(()=>JSON.parse(localStorage.getItem('botters.prefs')).mode), mode)
  await page.reload(); await page.locator('#play').waitFor({state:'visible'})
  await page.locator('#play').click(); await page.locator('#hud').waitFor({state:'visible'})
  const state = () => page.evaluate(async()=>fetch('/state?token='+localStorage.getItem('botters.session')).then(r=>r.json()))
  let frame = await state(); assert.equal(frame.options.mode,mode); assert.equal(frame.view.planets.length,16)
  while (frame.startsIn>0) { await page.waitForTimeout(100); frame=await state() }
  const keys=[]; await page.locator('#c').focus()
  for (const [key,type] of [['p','spore'],['l','locust'],['c','carapace']]) {
   await page.keyboard.press('Tab'); await page.keyboard.press(key); await page.waitForTimeout(250)
   const f=await state(), toast=await page.locator('#toast').textContent()
   assert.ok(toast.includes(type) && !toast.includes('✗'),toast)
   keys.push({key,type,toast,types:f.view.swarms.map(c=>({id:c.id,type:c.type,cocoon:c.cocoon}))})
  }
  await page.waitForTimeout(3500); const mid = await state()
  await page.screenshot({path:`review-play-${mode}.png`})
  await page.locator('#again').waitFor({state:'visible',timeout:60000})
  const end=await state(); assert.ok(end.report); assert.deepEqual(errors,[])
  await page.screenshot({path:`review-ended-${mode}.png`})
  results.push({mode,actual:end.options.mode,planets:end.view.planets.length,allies:mid.view.allies.length,foes:mid.view.totals.foes,hunger:mid.view.swarms.map(c=>c.hunger),keys,ended:end.view.ended,report:end.report,errors})
  await context.close()
 }
} finally {
 await writeFile('review-browser-results.json',JSON.stringify(results,null,2))
 await writeFile('review-browser-server.log',serverLog)
 await browser?.close(); server.kill(); await new Promise(r=>server.exitCode!==null?r():server.once('exit',r))
}
console.log(JSON.stringify(results,null,2))
