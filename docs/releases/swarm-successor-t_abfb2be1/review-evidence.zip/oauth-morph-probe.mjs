import assert from 'node:assert/strict'
import http from 'node:http'
import { Readable } from 'node:stream'
import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
const root = '/home/hermes/.hermes/kanban/boards/gimli/workspaces/t_c274105c/'
const { createWebMcp } = await import(root + 'web-mcp.js')
const { createHandler } = await import(root + 'online/http.js')
const { MemoryStore } = await import(root + 'online/store.js')
const { Client } = await import(root + 'node_modules/@modelcontextprotocol/sdk/dist/esm/client/index.js')
const { StreamableHTTPClientTransport } = await import(root + 'node_modules/@modelcontextprotocol/sdk/dist/esm/client/streamableHttp.js')
const listen = s => new Promise(r => s.listen(0, '127.0.0.1', () => r(`http://127.0.0.1:${s.address().port}`)))
const tunnelFetch = (url, init = {}) => new Promise((resolve, reject) => {
  const req = http.request(url, { method: init.method || 'GET', headers: Object.fromEntries(new Headers(init.headers)), signal: init.signal }, res => {
    const headers = new Headers(); for (let i=0;i<res.rawHeaders.length;i+=2) headers.append(res.rawHeaders[i],res.rawHeaders[i+1])
    resolve(new Response([204,205,304].includes(res.statusCode) ? null : Readable.toWeb(res), {status:res.statusCode,headers}))
  }); req.on('error',reject); req.end(init.body)
})
const dir = await mkdtemp('/srv/hermes-ssd/workspaces/botters/t_c274105c-review/private-probe-')
let handler, pairRequests = 0, app, client
let time = Date.now()
const upstreamServer = http.createServer((req,res)=>{ const u=new URL(req.url,'http://localhost'); if(u.pathname==='/next'){u.searchParams.set('timeout','0');req.url=u.pathname+u.search} if(u.pathname==='/agent/pair')pairRequests++;handler(req,res) })
const upstream = await listen(upstreamServer)
const identity = {id:'independent-oauth-morph',name:'Independent reviewer',emailVerified:true}
handler = createHandler(new MemoryStore(()=>time),{origin:upstream,env:{BOTTERS_AUTH_ORIGIN:upstream},now:()=>time,requireAccount:true,resolveAccount:async req=>req.headers.cookie==='review-human' ? identity : null})
const result = {candidate:'581ce19d05e3d1fde122049cdfe9f74a40ed34f7',scope:'local fixtures only'}
try {
  app=createWebMcp({server:upstream,origin:'https://review.example',oauth:{stateFile:dir+'/oauth.json'}})
  const local = await listen(app.server)
  const request=(path,init={})=>tunnelFetch(local+path,{...init,headers:{host:'review.example',origin:'https://review.example',...init.headers}})
  const form=(path,body,headers={})=>request(path,{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded',...headers},body:new URLSearchParams(body).toString()})
  const humanPost=async(path,body)=>{const r=await fetch(upstream+path,{method:'POST',headers:{cookie:'review-human',origin:upstream,'content-type':'application/json'},body:JSON.stringify(body)});assert.equal(r.status,200);return r.json()}
  const registered=await request('/register',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({client_name:'Independent morph probe',redirect_uris:['https://assistant.example/callback'],token_endpoint_auth_method:'none',grant_types:['authorization_code','refresh_token']})})
  assert.equal(registered.status,201)
  const registration=await registered.json(), verifier='q'.repeat(64),resource='https://review.example/mcp'
  const start=await request('/authorize?'+new URLSearchParams({client_id:registration.client_id,redirect_uri:registration.redirect_uris[0],response_type:'code',scope:'botters:play',resource,code_challenge:createHash('sha256').update(verifier).digest('base64url'),code_challenge_method:'S256'}))
  assert.equal(start.status,302)
  const cookie=start.headers.get('set-cookie').split(';')[0],location=start.headers.get('location')
  const html=await request(location,{headers:{cookie}}).then(r=>r.text())
  const pair=new URL(html.match(/href="(http[^" ]+)"/)[1].replaceAll('&amp;','&'))
  const human=await humanPost('/session',{})
  await humanPost('/agent/approve?token='+human.humanToken,{id:pair.searchParams.get('pair')})
  const consent=await form('/consent/complete',{transaction:new URL(location,'https://review.example').searchParams.get('transaction')},{cookie})
  assert.equal(consent.status,200)
  const callback=new URL((await consent.json()).redirect)
  const issued=await form('/token',{client_id:registration.client_id,grant_type:'authorization_code',code:callback.searchParams.get('code'),code_verifier:verifier,redirect_uri:registration.redirect_uris[0],resource})
  assert.equal(issued.status,200)
  const tokens=await issued.json()
  const transport=new StreamableHTTPClientTransport(new URL(local+'/mcp'),{requestInit:{headers:{host:'review.example',origin:'https://review.example',authorization:'Bearer '+tokens.access_token}},fetch:tunnelFetch})
  client=new Client({name:'independent-review',version:'1'});await client.connect(transport)
  result.tools=(await client.listTools()).tools.map(t=>t.name).sort()
  assert.deepEqual(result.tools,['join_match','wait_for_event','set_gambits','order_swarm','split_swarm','morph_swarm','release_swarm','call_human'].sort())
  const decode=r=>JSON.parse(r.content[0].text)
  const deniedHeadless=await client.callTool({name:'join_match',arguments:{vs:'easy',mode:'ffa6'}})
  assert.match(deniedHeadless.content[0].text,/human starts online matches/)
  await humanPost('/play?token='+human.humanToken,{vs:'easy',mode:'ffa6',minutes:3,planning:10,withAgent:true})
  time+=11000
  const joined=decode(await client.callTool({name:'join_match',arguments:{}}))
  assert.equal(joined.settings.mode,'ffa6')
  const swarm=Number(joined.state.yourSwarms[0].match(/^#(\d+)/)[1])
  const morphed=decode(await client.callTool({name:'morph_swarm',arguments:{swarm,type:'spore',why:'Independent OAuth integration verification'}}))
  assert.equal(morphed.ok,true)
  const frame=await fetch(upstream+'/state?token='+human.humanToken,{headers:{cookie:'review-human'}}).then(r=>r.json())
  assert.equal(frame.view.swarms.find(s=>s.id===swarm).type,'spore')
  result.authenticatedMorph={ok:true,mode:joined.settings.mode,type:'spore'}
  const before=frame.view.swarms.map(s=>({id:s.id,type:s.type}))
  await humanPost('/agent/revoke?token='+human.humanToken,{})
  const raw=await request('/mcp',{method:'POST',headers:{authorization:'Bearer '+tokens.access_token,'mcp-session-id':transport.sessionId,'content-type':'application/json',accept:'application/json, text/event-stream'},body:JSON.stringify({jsonrpc:'2.0',id:900,method:'tools/call',params:{name:'morph_swarm',arguments:{swarm,type:'locust',why:'must fail'}}})})
  assert.equal(raw.status,401)
  const after=await fetch(upstream+'/state?token='+human.humanToken,{headers:{cookie:'review-human'}}).then(r=>r.json())
  assert.deepEqual(after.view.swarms.map(s=>({id:s.id,type:s.type})),before)
  assert.equal(pairRequests,1)
  result.revokedMorph={status:raw.status,unchanged:true,pairRequests,noFallback:true}
  await new Promise(r=>setTimeout(r,1100))
  const health=await request('/health').then(r=>r.json());assert.equal(health.sessions,0);result.cleanup=health
  result.status='PASS'
} finally {
  await client?.close();await app?.close()
  await new Promise(r=>{upstreamServer.close(r);upstreamServer.closeAllConnections()})
  await rm(dir,{recursive:true})
  await writeFile('/srv/hermes-ssd/workspaces/botters/t_c274105c-review/oauth-morph-results.json',JSON.stringify(result,null,2))
}
console.log(JSON.stringify(result,null,2))
